# BattlesnakeReptarium
 Server for Battlesnake bots

## Setup
1. Copy a config \<env>.yml in the config folder and name it local.yml
2. Run main.go